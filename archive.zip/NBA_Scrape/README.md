# NBA_Scrape

NBA数据采集程序

使用Python语言编写，从BasketballReference、ESPN和NBA官网抓取数据，并存储到本地。

数据覆盖00-01赛季至14-15赛季的常规赛和季后赛（14-15季后赛除外），球员数据和头像，球队数据和logo。
