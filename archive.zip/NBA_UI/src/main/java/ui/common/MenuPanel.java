package ui.common;

import javax.swing.JPanel;

public class MenuPanel extends JPanel {

}
