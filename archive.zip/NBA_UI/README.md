# NBA_UI
NBA数据展示系统客户端
计划使用Java语言编写。