# NBA-Deworm
Deworm的软工三大作业迭代三：NBA数据采集、数据提供、数据展现、数据分析、数据同步

计划如下：
NBA_Live：数据同步（比赛直播）
NBA_Scrape：数据采集
NBA_Server：数据提供、数据分析
NBA_UI：数据展现
